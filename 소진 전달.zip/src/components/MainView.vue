<template>
  <FoodMap />
</template>

<script>
import FoodMap from '@/components/FoodMap/FoodMap.vue'

export default {
  name: 'MainView',
  components: {
    FoodMap
  },
  data() {
    return {
      
    };
  },

  mounted() {
    
  },

  methods: {
    
  },
};
</script>

<style lang="scss" scoped>

</style>