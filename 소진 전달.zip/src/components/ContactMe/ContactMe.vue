<template>
  <div>
    연락처 페이지
  </div>
</template>

<script>
export default {
  name: 'ContactMe',

  data() {
    return {
      
    };
  },

  mounted() {
    
  },

  methods: {
    
  },
};
</script>

<style lang="scss" scoped>

</style>