<template>
  <div>
    
  </div>
</template>

<script>
export default {
  name: 'ContactMeView',

  data() {
    return {
      
    };
  },

  mounted() {
    
  },

  methods: {
    
  },
};
</script>

<style lang="scss" scoped>

</style>