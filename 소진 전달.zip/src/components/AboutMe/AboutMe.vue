<template>
  <div>
    소개 페이지
  </div>
</template>

<script>
export default {
  name: 'AboutMe',

  data() {
    return {
      
    };
  },

  mounted() {
    
  },

  methods: {
    
  },
};
</script>

<style lang="scss" scoped>

</style>