<template>
  <div>라우터3</div>
</template>

<script>

export default {
  name: 'ErrorPage',
  components: {
  }
}
</script>

<style>

</style>